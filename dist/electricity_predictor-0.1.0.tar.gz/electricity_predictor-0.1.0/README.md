# Electricity Predictor

A Python package to predict whether electricity consumption is normal or abnormal based on a CSV file input.

## Installation

```bash
pip install electricity_predictor
